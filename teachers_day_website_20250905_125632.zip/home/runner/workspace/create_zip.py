#!/usr/bin/env python3
"""
Teachers Day Website Zipper
Creates a zip file with all project files for easy sharing
"""

import os
import zipfile
import shutil
from pathlib import Path
import datetime

def create_teachers_day_zip():
    """Create a zip file with all Teachers Day website files"""
    
    # Get current timestamp for unique filename
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"teachers_day_website_{timestamp}.zip"
    
    print("🎓 Creating Teachers Day Website ZIP file...")
    print(f"📁 Output: {zip_filename}")
    
    # Files and directories to include
    include_patterns = [
        # Frontend files
        "client/",
        "server/",
        "shared/",
        
        # Config files
        "package.json",
        "package-lock.json",
        "tailwind.config.ts",
        "tsconfig.json",
        "vite.config.ts",
        "postcss.config.js",
        "components.json",
        "drizzle.config.ts",
        
        # Documentation
        "replit.md",
        
        # Attached assets (original HTML files)
        "attached_assets/"
    ]
    
    # Files and directories to exclude
    exclude_patterns = [
        "node_modules/",
        ".git/",
        ".vite/",
        "dist/",
        "build/",
        ".env",
        ".env.local",
        "*.log",
        ".DS_Store",
        "Thumbs.db",
        "__pycache__/",
        "*.pyc",
        ".pytest_cache/",
        "coverage/",
        ".nyc_output/"
    ]
    
    def should_exclude(filepath):
        """Check if a file should be excluded"""
        filepath_str = str(filepath)
        for pattern in exclude_patterns:
            if pattern in filepath_str:
                return True
        return False
    
    try:
        with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zipf:
            
            # Add project files
            for pattern in include_patterns:
                path = Path(pattern)
                
                if path.is_file():
                    if not should_exclude(path):
                        print(f"📄 Adding file: {path}")
                        zipf.write(path, path)
                        
                elif path.is_dir():
                    for file_path in path.rglob("*"):
                        if file_path.is_file() and not should_exclude(file_path):
                            print(f"📄 Adding: {file_path}")
                            zipf.write(file_path, file_path)
                            
                else:
                    print(f"⚠️  Pattern not found: {pattern}")
            
            # Add this script itself
            script_path = Path(__file__)
            if script_path.exists():
                print(f"📄 Adding: {script_path}")
                zipf.write(script_path, script_path)
            
            # Create a README for the zip
            readme_content = """# Teachers Day Celebration Website 🎓

## About
This is a fun, interactive Teachers' Day celebration website created by BACK ✘ BENCHERS!

## Features
- ✨ Multi-page interactive experience
- 🎵 Bhojpuri music on each page (different songs!)
- 🎊 Confetti effects and animations
- 😂 Funny quiz questions with runaway buttons
- 💝 Emotional appreciation messages
- 🎭 Playful Hinglish content
- 📱 Mobile responsive design

## Pages
1. **Homepage** - Welcome with confetti effects
2. **Appreciation** - Interactive appreciation with runaway buttons
3. **Celebration** - Spinning animations and celebration
4. **Quiz** - Funny questions with moving buttons
5. **Advanced Quiz** - More interactive challenges
6. **Emotional** - Heartfelt messages for teachers

## How to Run
1. Install Node.js (version 18 or higher)
2. Install dependencies: `npm install`
3. Start development server: `npm run dev`
4. Open browser to: `http://localhost:5000`

## Tech Stack
- React 18 with TypeScript
- Tailwind CSS for styling
- Wouter for routing
- Express.js backend
- Web Audio API for music
- Framer Motion for animations

## Music
Each page has its own unique Bhojpuri-style melody generated using Web Audio API:
- Click the music controls in the top-right corner
- Different tempo and melody for each page
- Auto-plays after user interaction

## MADE BY BACK ✘ BENCHERS ✨
A tribute to all the amazing teachers out there! 🙏❤️

---
Generated on: """ + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + """
"""
            
            zipf.writestr("README.md", readme_content)
            print("📄 Adding: README.md")
        
        # Get file size
        file_size = os.path.getsize(zip_filename) / (1024 * 1024)  # MB
        
        print(f"\n✅ SUCCESS!")
        print(f"📦 Created: {zip_filename}")
        print(f"📊 Size: {file_size:.2f} MB")
        print(f"🎉 Your Teachers Day website is ready to share!")
        
        return zip_filename
        
    except Exception as e:
        print(f"❌ Error creating zip file: {e}")
        return None

if __name__ == "__main__":
    print("=" * 50)
    print("🎓 TEACHERS DAY WEBSITE ZIPPER 🎓")
    print("=" * 50)
    
    zip_file = create_teachers_day_zip()
    
    if zip_file:
        print(f"\n🚀 Ready to deploy your Teachers Day website!")
        print(f"📤 Share the file: {zip_file}")
        print("\n💡 Instructions:")
        print("1. Extract the zip file")
        print("2. Run 'npm install'")
        print("3. Run 'npm run dev'")
        print("4. Enjoy the celebration! 🎊")
    
    print("\n" + "=" * 50)