import { useEffect } from "react";
import { useLocation } from "wouter";
import AnimatedElements from "@/components/AnimatedElements";
import BhojpuriMusic from "@/components/BhojpuriMusic";

const emotionalLines = [
  {
    emoji: "👨‍🏫👩‍🏫",
    hindi: "Teacher nahi, aap toh hamare second parents hain! ❤️",
    english: "You're not just a teacher, you're our second parents!",
    delay: "0s"
  },
  {
    emoji: "📚✨",
    hindi: "Aapne humein sikhaya nahi, zindagi jeena sikhaya hai! 🙏",
    english: "You didn't just teach us subjects, you taught us how to live!",
    delay: "0.5s"
  },
  {
    emoji: "🌟💡",
    hindi: "Har galti pe daanta nahi, pyaar se samjhaya hai! 💕",
    english: "You never just scolded us for mistakes, you explained with love!",
    delay: "1s"
  },
  {
    emoji: "🎓❤️",
    hindi: "Aap ke bina toh hum kuch bhi nahi the sir/ma'am! 😭💝",
    english: "Without you, we were nothing sir/ma'am!",
    delay: "1.5s"
  },
  {
    emoji: "🙏🌈",
    hindi: "Homework dena band kar do, but humein chhodna mat! 😂❤️",
    english: "Stop giving homework, but never leave us!",
    delay: "2s"
  },
  {
    emoji: "💖📖",
    hindi: "Books se zyada, aapne life ke lessons diye hain! 🌟",
    english: "More than books, you gave us life lessons!",
    delay: "2.5s"
  },
  {
    emoji: "🏆👑",
    hindi: "Google Uncle se bhi zyada smart ho aap! Respect! 🫡❤️",
    english: "You're smarter than even Google Uncle! Respect!",
    delay: "3s"
  }
];

export default function EmotionalPage() {
  const [, navigate] = useLocation();

  useEffect(() => {
    document.title = "Emotional Lines for Teachers - Teachers' Day";
    
    // Create floating hearts
    const createFloatingHearts = () => {
      const hearts = ['❤️', '💖', '💝', '💕', '💗', '💓', '💘', '🧡', '💙', '💚', '💛', '💜'];
      
      for (let i = 0; i < 8; i++) {
        const heart = document.createElement('div');
        heart.className = 'floating-hearts';
        heart.textContent = hearts[Math.floor(Math.random() * hearts.length)];
        heart.style.left = Math.random() * window.innerWidth + 'px';
        heart.style.animationDelay = Math.random() * 6 + 's';
        heart.style.animationDuration = (Math.random() * 3 + 4) + 's';
        document.body.appendChild(heart);
        
        setTimeout(() => {
          if (heart.parentNode) {
            heart.parentNode.removeChild(heart);
          }
        }, 8000);
      }
    };

    // Create hearts every 3 seconds
    const heartInterval = setInterval(createFloatingHearts, 3000);
    createFloatingHearts(); // Initial hearts

    return () => clearInterval(heartInterval);
  }, []);

  return (
    <div className="min-h-screen emotional-bg p-4 relative overflow-x-hidden">
      <BhojpuriMusic page="emotional" />
      <AnimatedElements type="hearts" />
      
      <div className="max-w-4xl mx-auto py-8">
        <h1 
          className="text-4xl md:text-6xl font-bold text-white text-center mb-12 title-pulse"
          style={{ textShadow: "3px 3px 6px rgba(0,0,0,0.5)" }}
          data-testid="emotional-title"
        >
          💝 Teachers ke liye Emotional Lines 💝
        </h1>
        
        <div className="text-center mb-8">
          <h2 
            className="text-2xl md:text-3xl text-white font-bold title-pulse"
            style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.5)" }}
            data-testid="credit-emotional"
          >
            ✨ MADE BY BACK ✘ BENCHERS ✨
          </h2>
        </div>

        <div className="space-y-8">
          {emotionalLines.map((line, index) => (
            <div 
              key={index}
              className="bg-white/95 rounded-3xl p-8 text-center shadow-2xl border-4 border-primary relative overflow-hidden card-shine card-float"
              style={{ animationDelay: line.delay }}
              data-testid={`emotional-card-${index}`}
            >
              <div 
                className="text-5xl mb-4"
                style={{ animation: `emojiJump 1.5s ease-in-out infinite ${line.delay}` }}
                data-testid={`emoji-${index}`}
              >
                {line.emoji}
              </div>
              
              <div 
                className="text-2xl md:text-3xl text-primary font-bold mb-4 title-pulse"
                data-testid={`hindi-text-${index}`}
              >
                "{line.hindi}"
              </div>
              
              <div 
                className="text-lg md:text-xl text-gray-600 italic"
                data-testid={`english-text-${index}`}
              >
                {line.english}
              </div>
            </div>
          ))}

          {/* Special BACK x BENCHERS Message */}
          <div 
            className="bg-gradient-to-r from-accent to-purple-600 text-white rounded-3xl p-8 text-center shadow-2xl relative popup-shake"
            data-testid="special-message"
          >
            <h3 
              className="text-3xl md:text-4xl font-bold mb-4 title-pulse"
              data-testid="special-title"
            >
              🎊 BACK ✘ BENCHERS Special Message 🎊
            </h3>
            
            <div 
              className="text-xl md:text-2xl font-bold mb-4"
              data-testid="special-hindi"
            >
              "Hum chahe kitne bhi naughty hon, aap hamare dil mein special place rakhe hain! ❤️"
            </div>
            
            <div 
              className="text-lg md:text-xl italic opacity-90"
              data-testid="special-english"
            >
              No matter how naughty we are, you hold a special place in our hearts!
            </div>
          </div>
        </div>

        {/* Navigation Buttons */}
        <div 
          className="fixed bottom-6 left-1/2 transform -translate-x-1/2 flex gap-4 z-50"
          data-testid="navigation-buttons"
        >
          <button
            onClick={() => navigate("/quiz")}
            className="bg-gradient-to-r from-primary to-secondary text-white px-6 py-3 rounded-full text-lg font-bold hover:scale-105 transition-transform duration-300 shadow-lg"
            style={{ animation: "buttonGlow 2s ease-in-out infinite alternate" }}
            data-testid="button-fun-questions"
          >
            🤔 Fun Questions
          </button>
          
          <button
            onClick={() => navigate("/")}
            className="bg-gradient-to-r from-accent to-purple-600 text-white px-6 py-3 rounded-full text-lg font-bold hover:scale-105 transition-transform duration-300 shadow-lg"
            style={{ animation: "buttonGlow 2s ease-in-out infinite alternate" }}
            data-testid="button-back-start"
          >
            🎉 Back to Start
          </button>
        </div>
      </div>
    </div>
  );
}
