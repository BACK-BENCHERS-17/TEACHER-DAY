import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import PopupMessage from "@/components/PopupMessage";
import BhojpuriMusic from "@/components/BhojpuriMusic";

export default function QuizPage() {
  const [, navigate] = useLocation();
  const [noClickCount, setNoClickCount] = useState(0);
  const [buttonPosition, setButtonPosition] = useState({ x: 0, y: 0 });
  const [showNextBtn, setShowNextBtn] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState("");
  const [noButtonText, setNoButtonText] = useState("नहीं 😬");

  useEffect(() => {
    document.title = "Funny Questions Quiz - Teachers' Day";
  }, []);

  const getRandomPosition = () => {
    const maxX = Math.max(100, window.innerWidth - 200);
    const maxY = Math.max(200, window.innerHeight - 150);
    return {
      x: Math.max(20, Math.random() * maxX),
      y: Math.max(150, Math.random() * maxY)
    };
  };

  const handleNoButtonHover = () => {
    if (noClickCount < 15) {
      const pos = getRandomPosition();
      setButtonPosition(pos);
      
      const funnyTexts = [
        "Nope! Bhag raha hun! 🏃‍♂️",
        "Pakad ke dikha! 😜",
        "No way Jose! 🙈",
        "Fast & Furious button! 🏎️"
      ];
      setNoButtonText(funnyTexts[Math.floor(Math.random() * funnyTexts.length)]);
      setPopupMessage("😂 No button भाग गया फिर से!");
      setShowPopup(true);
    }
  };

  const handleNoButtonClick = () => {
    const newCount = noClickCount + 1;
    setNoClickCount(newCount);
    
    if (newCount >= 15) {
      setNoButtonText("Theek hai! Haar gaya main! 😭");
      setPopupMessage("😂 Finally caught the button! Now selecting YES...");
      setShowPopup(true);
      
      setTimeout(() => {
        handleYesAnswer();
      }, 1500);
    } else {
      setPopupMessage(`😂 Attempt ${newCount}/15: Keep chasing the button!`);
      setShowPopup(true);
    }
  };

  const handleYesAnswer = () => {
    setPopupMessage("🎉 Correct answer! Teacher appreciation unlocked!");
    setShowPopup(true);
    
    setTimeout(() => {
      setShowNextBtn(true);
    }, 2000);
  };

  return (
    <div className="min-h-screen gradient-bg-2 flex items-center justify-center p-4 relative overflow-hidden">
      <BhojpuriMusic page="quiz" />
      <div className="bg-white/95 rounded-3xl p-8 md:p-12 max-w-2xl w-full text-center shadow-2xl border-4 border-primary relative card-float">
        <h1 
          className="text-3xl md:text-4xl text-primary font-bold mb-8 btn-wiggle"
          data-testid="quiz-title"
        >
          🤔 गुरुजी के बारे में प्रश्न!
        </h1>
        
        <p 
          className="text-xl md:text-2xl text-gray-700 font-bold mb-10 leading-relaxed"
          data-testid="quiz-question"
        >
          क्या आप अपने teacher को "Google से भी ज्यादा smart" मानते हैं? 😄
        </p>
        
        <div className="flex justify-center gap-8 md:gap-12 mb-8 relative" style={{ minHeight: "80px" }}>
          <button
            onClick={handleYesAnswer}
            className="bg-gradient-to-r from-green-400 to-green-600 text-white px-8 py-4 rounded-full text-lg font-bold hover:scale-110 transition-transform duration-300 shadow-lg"
            data-testid="button-yes"
          >
            हाँ बिल्कुल! 😍
          </button>
          
          <button
            className="bg-gradient-to-r from-red-400 to-red-600 text-white px-8 py-4 rounded-full text-lg font-bold cursor-pointer no-btn-wiggle transition-all duration-200"
            style={{
              position: "absolute",
              right: buttonPosition.x || 0,
              top: buttonPosition.y || 0,
              background: noClickCount >= 15 
                ? "linear-gradient(45deg, #00ff88, #00cc6a)" 
                : "linear-gradient(45deg, #ff4757, #ff6b6b)"
            }}
            onMouseEnter={handleNoButtonHover}
            onClick={handleNoButtonClick}
            data-testid="button-no"
          >
            {noButtonText}
          </button>
        </div>
        
        {showNextBtn && (
          <button
            onClick={() => navigate("/advanced-quiz")}
            className="bg-gradient-to-r from-secondary to-accent text-white px-6 py-3 rounded-full text-lg font-bold hover:scale-105 transition-transform duration-300"
            data-testid="button-next-question"
          >
            अगला प्रश्न गुरुजी 📚
          </button>
        )}
      </div>

      <PopupMessage
        show={showPopup}
        message={popupMessage}
        onClose={() => setShowPopup(false)}
      />
    </div>
  );
}
