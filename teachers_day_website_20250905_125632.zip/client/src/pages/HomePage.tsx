import { useEffect } from "react";
import { useLocation } from "wouter";
import ConfettiEffect from "@/components/ConfettiEffect";
import BhojpuriMusic from "@/components/BhojpuriMusic";

export default function HomePage() {
  const [, navigate] = useLocation();

  useEffect(() => {
    document.title = "Teachers' Day Celebration - BACK ✘ BENCHERS";
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-600 to-blue-600 relative overflow-hidden flex items-center justify-center">
      <BhojpuriMusic page="home" />
      <ConfettiEffect />
      
      <div className="text-center z-10 relative px-4">
        <h1 
          className="text-6xl md:text-8xl font-bold text-white mb-8 title-pulse"
          data-testid="main-title"
        >
          🎉 Teachers' Day 🎉
        </h1>
        
        <div className="bg-white/95 rounded-3xl p-8 md:p-12 max-w-2xl mx-auto shadow-2xl border-4 border-primary">
          <h2 
            className="text-3xl md:text-4xl font-bold text-primary mb-6"
            data-testid="welcome-title"
          >
            Welcome Guruji! 🙏
          </h2>
          
          <p 
            className="text-xl md:text-2xl text-gray-700 mb-8 leading-relaxed"
            data-testid="welcome-message"
          >
            Hamari special website mein aapka swagat hai! 
            Hum BACK ✘ BENCHERS ne aapke liye kuch special banaya hai! ❤️
          </p>
          
          <button
            onClick={() => navigate("/appreciation")}
            className="bg-gradient-to-r from-primary to-secondary text-white px-8 py-4 rounded-full text-xl font-bold hover:scale-105 transition-transform duration-300 shadow-lg"
            data-testid="button-start"
          >
            Shuru Karte Hain! 🚀
          </button>
        </div>
        
        <div 
          className="mt-8 text-white text-xl font-bold title-pulse"
          data-testid="credit-text"
        >
          ✨ MADE BY BACK ✘ BENCHERS ✨
        </div>
      </div>
    </div>
  );
}
