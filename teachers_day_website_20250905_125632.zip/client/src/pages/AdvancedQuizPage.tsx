import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import PopupMessage from "@/components/PopupMessage";
import BhojpuriMusic from "@/components/BhojpuriMusic";

interface QuizQuestion {
  question: string;
  options: string[];
  correct: number;
  wrongResponses: string[];
}

const quizData: QuizQuestion[] = [
  {
    question: "Teacher ne homework diya, aur aap kya kehte hain?",
    options: [
      "Arre yaar! Phir se homework! 😩",
      "Bilkul sir/ma'am! Main karunga! 😇",
      "Kitne pages? Only 50? Easy! 😎",
      "Teacher, aap bahut ache hain! ❤️"
    ],
    correct: 3,
    wrongResponses: [
      "😂 Homework se bhagna nahi chahiye!",
      "🙈 Sach bolna seekho!",
      "😜 Jhooth ka button bhag gaya!"
    ]
  },
  {
    question: "Teacher angry hain, aap kya karte hain?",
    options: [
      "Chhup jata hun desk ke peeche 🙈",
      "Sorry sir/ma'am, next time nahi hoga 🙏",
      "Dusre student ko blame karta hun 😅",
      "Respectfully sorry kehta hun ❤️"
    ],
    correct: 3,
    wrongResponses: [
      "😂 Chupna solution nahi hai!",
      "🤭 Dusron ko blame karna galat hai!",
      "😜 Honest answer do!"
    ]
  },
  {
    question: "Teacher ka birthday hai, aap kya gift dete hain?",
    options: [
      "Kuch nahi, bhool gaya 😅",
      "Ek beautiful card banata hun 💝",
      "Paisa collect karke something expensive 💰",
      "Heartfelt thank you note ❤️"
    ],
    correct: 3,
    wrongResponses: [
      "😱 Birthday bhoolna kitna bura!",
      "💸 Paisa important nahi, feelings important!",
      "😂 Sab buttons bhag gaye!"
    ]
  }
];

export default function AdvancedQuizPage() {
  const [, navigate] = useLocation();
  const [currentQuiz, setCurrentQuiz] = useState(0);
  const [wrongAttempts, setWrongAttempts] = useState(0);
  const [showPopup, setShowPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState("");
  const [showNextBtn, setShowNextBtn] = useState(false);
  const [runawayButtons, setRunawayButtons] = useState<Set<number>>(new Set());
  const [correctButton, setCorrectButton] = useState<number | null>(null);

  useEffect(() => {
    document.title = "More Funny Questions - Teachers' Day";
  }, []);

  const handleAnswer = (selectedIndex: number) => {
    const quiz = quizData[currentQuiz];
    
    if (selectedIndex === quiz.correct) {
      setCorrectButton(selectedIndex);
      const correctMessages = [
        "🎉 Bilkul sahi! Teacher khush ho gaye!",
        "💝 Perfect answer! Shabash!",
        "🌟 Wah! Teacher proud feel kar rahe hain!",
        "❤️ Exactly! Yahi toh chahiye!",
        "🎊 100% correct! Amazing!"
      ];
      setPopupMessage(correctMessages[Math.floor(Math.random() * correctMessages.length)]);
      setShowPopup(true);
      
      setTimeout(() => {
        if (currentQuiz < quizData.length - 1) {
          setCurrentQuiz(currentQuiz + 1);
          setWrongAttempts(0);
          setRunawayButtons(new Set());
          setCorrectButton(null);
        } else {
          setShowNextBtn(true);
          setPopupMessage("🎉 All questions complete! Ab emotional lines padhiye! 💝");
          setShowPopup(true);
        }
      }, 2000);
    } else {
      const newWrongAttempts = wrongAttempts + 1;
      setWrongAttempts(newWrongAttempts);
      setRunawayButtons(prev => new Set([...Array.from(prev), selectedIndex]));
      
      const wrongMessage = quiz.wrongResponses[Math.floor(Math.random() * quiz.wrongResponses.length)];
      setPopupMessage(wrongMessage);
      setShowPopup(true);
      
      if (newWrongAttempts >= 5) {
        setTimeout(() => {
          setCorrectButton(quiz.correct);
          setPopupMessage("😂 Thak gaye na? Sahi answer select kar diya!");
          setShowPopup(true);
          
          setTimeout(() => {
            if (currentQuiz < quizData.length - 1) {
              setCurrentQuiz(currentQuiz + 1);
              setWrongAttempts(0);
              setRunawayButtons(new Set());
              setCorrectButton(null);
            } else {
              setShowNextBtn(true);
            }
          }, 2000);
        }, 1000);
      }
    }
  };

  const currentQuestion = quizData[currentQuiz];

  return (
    <div className="min-h-screen gradient-bg-3 flex items-center justify-center p-4 relative">
      <BhojpuriMusic page="advanced-quiz" />
      <div className="bg-white/98 rounded-3xl p-8 md:p-12 max-w-3xl w-full text-center shadow-2xl border-4 border-primary relative overflow-hidden" style={{ animation: "dance 3s ease-in-out infinite" }}>
        <h1 
          className="text-3xl md:text-4xl text-primary font-bold mb-8 btn-wiggle"
          style={{ textShadow: "3px 3px 6px rgba(0,0,0,0.2)" }}
          data-testid="quiz-title-advanced"
        >
          🎭 Aur Funny Questions!
        </h1>
        
        <p 
          className="text-xl md:text-2xl text-gray-700 font-bold mb-10 leading-relaxed"
          data-testid="quiz-question-advanced"
        >
          {currentQuestion.question}
        </p>
        
        <div className="flex flex-col gap-4 mb-8 relative" style={{ minHeight: "300px" }}>
          {currentQuestion.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              className={`px-6 py-4 rounded-xl text-lg font-bold transition-all duration-300 shadow-lg ${
                correctButton === index
                  ? "bg-gradient-to-r from-green-400 to-green-600 text-white"
                  : runawayButtons.has(index)
                  ? "bg-gradient-to-r from-red-400 to-red-600 text-white wrong-btn absolute"
                  : "bg-gradient-to-r from-pink-400 to-purple-400 text-gray-800 hover:scale-105"
              }`}
              style={runawayButtons.has(index) ? {
                left: Math.random() * 200 + 'px',
                top: Math.random() * 200 + 'px'
              } : {}}
              disabled={correctButton !== null}
              data-testid={`option-${index}`}
            >
              {option}
            </button>
          ))}
        </div>
        
        {showNextBtn && (
          <button
            onClick={() => navigate("/emotional")}
            className="bg-gradient-to-r from-accent to-purple-600 text-white px-8 py-4 rounded-full text-lg font-bold hover:scale-105 transition-transform duration-300 shadow-lg"
            data-testid="button-emotional-lines"
          >
            Emotional Lines Padhiye! 💝
          </button>
        )}
      </div>

      <PopupMessage
        show={showPopup}
        message={popupMessage}
        onClose={() => setShowPopup(false)}
      />
    </div>
  );
}
