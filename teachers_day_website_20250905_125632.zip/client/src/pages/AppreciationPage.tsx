import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import AnimatedElements from "@/components/AnimatedElements";
import PopupMessage from "@/components/PopupMessage";
import BhojpuriMusic from "@/components/BhojpuriMusic";

export default function AppreciationPage() {
  const [, navigate] = useLocation();
  const [runawayClickCount, setRunawayClickCount] = useState(0);
  const [isRunawayRunning, setIsRunawayRunning] = useState(false);
  const [buttonPosition, setButtonPosition] = useState({ x: 0, y: 0 });
  const [buttonText, setButtonText] = useState("Aage chalte hain Guruji! 🎯");
  const [showPopup, setShowPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState("");

  useEffect(() => {
    document.title = "Teacher Appreciation Party - Teachers' Day";
    
    // Set initial random position
    const initialPos = getRandomPosition();
    setButtonPosition(initialPos);
  }, []);

  const getRandomPosition = () => {
    const maxX = Math.max(100, window.innerWidth - 300);
    const maxY = Math.max(100, window.innerHeight - 100);
    return {
      x: Math.max(20, Math.random() * maxX),
      y: Math.max(100, Math.random() * maxY)
    };
  };

  const moveButton = () => {
    if (!isRunawayRunning) return;
    
    const pos = getRandomPosition();
    setButtonPosition(pos);
    
    setTimeout(moveButton, 1000);
  };

  const handleButtonHover = () => {
    if (runawayClickCount < 3) {
      setIsRunawayRunning(true);
      const pos = getRandomPosition();
      setButtonPosition(pos);
      setButtonText("😊 आपके लिए यहाँ है!");
      setPopupMessage("🏃‍♂️ Main bhag raha hun! Pakadiye!");
      setShowPopup(true);
      moveButton();
    }
  };

  const handleButtonClick = () => {
    const newCount = runawayClickCount + 1;
    setRunawayClickCount(newCount);
    
    if (newCount >= 3) {
      setIsRunawayRunning(false);
      setButtonText("🎉 बहुत खुशी! आगे बढ़ते हैं...");
      setPopupMessage("🎊 Wonderful! Moving to next page...");
      setShowPopup(true);
      
      setTimeout(() => {
        navigate("/celebration");
      }, 2000);
    } else {
      setButtonText(`${3 - newCount} बार और क्लिक करें! 😊`);
      setPopupMessage(`Attempt ${newCount}/3: Keep trying! 💪`);
      setShowPopup(true);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col items-center justify-center p-4 disco-bg">
      <BhojpuriMusic page="appreciation" />
      <AnimatedElements type="dancing" />
      
      <h1 
        className="text-4xl md:text-6xl font-bold text-white text-center mb-8 z-10 relative title-pulse"
        style={{ textShadow: "0 0 20px #ffffff, 0 0 40px #ffffff" }}
        data-testid="page-title"
      >
        Teacher Appreciation Party! 🎊
      </h1>
      
      <div className="bg-white/95 p-6 md:p-8 rounded-3xl max-w-2xl mx-4 text-center relative z-50 border-4 border-primary">
        <h2 
          className="text-2xl md:text-3xl text-primary font-bold mb-4"
          data-testid="dear-teacher-title"
        >
          Dear Teacher Sir/Madam! 😍
        </h2>
        
        <p 
          className="text-lg md:text-xl text-gray-700 leading-relaxed mb-6"
          data-testid="appreciation-message"
        >
          Aapki mehnat, patience aur love ke liye humara respect aur gratitude! 
          Aap hi humare life ke sachhe guide hain! 🙏✨
          <br /><br />
          <strong className="text-secondary text-xl">✨ MADE BY BACK ✘ BENCHERS ✨</strong>
        </p>
      </div>
      
      <button
        className="runaway-btn text-white px-8 py-4 rounded-full text-lg md:text-xl font-bold z-10 border-none cursor-pointer transition-all duration-200"
        style={{
          position: "absolute",
          left: `${buttonPosition.x}px`,
          top: `${buttonPosition.y}px`,
          background: runawayClickCount >= 3 
            ? "linear-gradient(45deg, #00ff00, #00aa00)" 
            : "linear-gradient(45deg, #ff4757, #ff6b9d)"
        }}
        onMouseEnter={handleButtonHover}
        onClick={handleButtonClick}
        data-testid="runaway-button"
      >
        {buttonText}
      </button>

      <PopupMessage
        show={showPopup}
        message={popupMessage}
        onClose={() => setShowPopup(false)}
      />
    </div>
  );
}
