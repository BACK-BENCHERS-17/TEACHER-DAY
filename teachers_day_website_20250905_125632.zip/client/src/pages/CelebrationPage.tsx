import { useEffect } from "react";
import { useLocation } from "wouter";
import AnimatedElements from "@/components/AnimatedElements";
import BhojpuriMusic from "@/components/BhojpuriMusic";

export default function CelebrationPage() {
  const [, navigate] = useLocation();

  useEffect(() => {
    document.title = "Celebration Page - Teachers' Day";
  }, []);

  return (
    <div className="min-h-screen gradient-bg-1 overflow-hidden p-4 relative">
      <BhojpuriMusic page="celebration" />
      <AnimatedElements type="spinning" />
      <AnimatedElements type="bouncing" />
      
      <h1 
        className="text-3xl md:text-5xl font-bold text-white text-center mb-8 title-pulse"
        style={{ textShadow: "2px 2px 8px rgba(0,0,0,0.5)" }}
        data-testid="congratulations-title"
      >
        Arre Wah! Teacher Sir/Madam aap yahan tak pahunch gaye! 🎉
      </h1>
      
      <div className="bg-white/95 p-6 md:p-8 rounded-3xl max-w-3xl mx-auto text-center border-4 border-primary relative overflow-hidden card-shine">
        <h2 
          className="text-2xl md:text-3xl text-primary font-bold mb-6"
          data-testid="congratulations-subtitle"
        >
          Congratulations Guruji! 🏆
        </h2>
        
        <p 
          className="text-lg md:text-xl text-gray-700 leading-relaxed mb-6"
          data-testid="celebration-message"
        >
          Aapne humari puri website dekhi! 😍 We hope aapko enjoy kiya hoga...<br />
          Hum students chahe kitne bhi naughty hon, but aap humesha hamare dil mein special place rakhenge! ❤️
          <br /><br />
          <strong className="text-primary text-xl">Teachers Day ki dher saari wishes aur love! 🎊</strong>
        </p>
        
        <h3 
          className="text-xl md:text-2xl text-secondary font-bold mb-6"
          data-testid="credit-celebration"
        >
          💝 MADE BY BACK ✘ BENCHERS 💝
        </h3>
        
        <button
          onClick={() => navigate("/quiz")}
          className="bg-gradient-to-r from-primary to-secondary text-white px-6 py-3 rounded-full text-lg font-bold hover:scale-105 transition-transform duration-300"
          data-testid="button-funny-questions"
        >
          Aur funny questions! 🤔
        </button>
      </div>
      
      <div 
        className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-black/80 text-white p-4 rounded-xl text-center border-2 border-pink-500 z-50 popup-shake"
        data-testid="respect-message"
      >
        Sachhi mein, apne teachers ka humesha respect karna chahiye! ❤️
      </div>
    </div>
  );
}
