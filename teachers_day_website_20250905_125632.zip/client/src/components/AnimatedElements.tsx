import { useEffect } from "react";

interface AnimatedElementsProps {
  type: "dancing" | "spinning" | "bouncing" | "hearts";
}

export default function AnimatedElements({ type }: AnimatedElementsProps) {
  useEffect(() => {
    let interval: NodeJS.Timeout;

    const createElement = () => {
      let element: HTMLDivElement;
      let content: string[];
      let className: string;

      switch (type) {
        case "dancing":
          content = ['💃', '🕺', '🎵', '🎶', '⚡', '🔥', '💥', '🌟'];
          className = 'dancing-text';
          break;
        case "spinning":
          content = ['🎉', '📚', '👨‍🏫', '👩‍🏫', '🍎', '✏️', '📝', '🎓', '⭐', '💝'];
          className = 'spinning-text';
          break;
        case "bouncing":
          content = ['🎊', '🎉', '🎁', '🌟', '⚡', '💥', '🔥', '✨'];
          className = 'bouncing-emoji';
          break;
        case "hearts":
          content = ['❤️', '💖', '💝', '💕', '💗', '💓', '💘', '🧡', '💙', '💚', '💛', '💜'];
          className = 'floating-hearts';
          break;
        default:
          return;
      }

      const count = type === "spinning" ? 15 : 8;
      const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];

      for (let i = 0; i < count; i++) {
        element = document.createElement('div');
        element.className = className;
        element.textContent = content[Math.floor(Math.random() * content.length)];
        element.style.left = Math.random() * window.innerWidth + 'px';
        element.style.top = Math.random() * window.innerHeight + 'px';
        
        if (type === "spinning") {
          element.style.color = colors[Math.floor(Math.random() * colors.length)];
        }
        
        if (type === "hearts") {
          element.style.animationDelay = Math.random() * 6 + 's';
          element.style.animationDuration = (Math.random() * 3 + 4) + 's';
        } else {
          element.style.animationDelay = Math.random() * 2 + 's';
        }
        
        document.body.appendChild(element);
        
        const timeout = type === "bouncing" ? 6000 : type === "hearts" ? 8000 : type === "spinning" ? 4000 : 5000;
        setTimeout(() => {
          if (element.parentNode) {
            element.parentNode.removeChild(element);
          }
        }, timeout);
      }
    };

    if (type === "dancing") {
      createElement();
      interval = setInterval(createElement, 5000);
    } else if (type === "spinning" || type === "bouncing") {
      createElement();
      interval = setInterval(createElement, type === "spinning" ? 2000 : 3000);
    } else if (type === "hearts") {
      createElement();
      interval = setInterval(createElement, 3000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [type]);

  return null;
}
