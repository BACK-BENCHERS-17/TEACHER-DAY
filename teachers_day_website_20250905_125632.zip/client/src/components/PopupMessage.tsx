import { useEffect } from "react";

interface PopupMessageProps {
  show: boolean;
  message: string;
  onClose: () => void;
}

export default function PopupMessage({ show, message, onClose }: PopupMessageProps) {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onClose();
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [show, onClose]);

  if (!show) return null;

  return (
    <div 
      className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-primary to-secondary text-white p-6 rounded-2xl text-lg font-bold shadow-2xl z-[1000] border-4 border-white popup-shake"
      data-testid="popup-message"
    >
      <div data-testid="popup-text">{message}</div>
      <button
        onClick={onClose}
        className="bg-white text-primary px-4 py-2 rounded-full mt-4 text-sm font-bold hover:scale-105 transition-transform"
        data-testid="popup-close"
      >
        समझ गए! 🙏
      </button>
    </div>
  );
}
