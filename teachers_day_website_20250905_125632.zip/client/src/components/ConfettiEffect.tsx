import { useEffect } from "react";

export default function ConfettiEffect() {
  useEffect(() => {
    const container = document.getElementById('confetti-container');
    if (!container) return;

    const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57', '#ff9ff3'];
    
    function createConfetti() {
      const confetti = document.createElement('div');
      confetti.className = 'confetti-piece';
      confetti.style.left = Math.random() * 100 + '%';
      confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      confetti.style.animationDelay = Math.random() * 3 + 's';
      confetti.style.animationDuration = (Math.random() * 2 + 2) + 's';
      if (container) {
        container.appendChild(confetti);
      }
      
      setTimeout(() => {
        if (confetti.parentNode) {
          confetti.parentNode.removeChild(confetti);
        }
      }, 5000);
    }
    
    const interval = setInterval(createConfetti, 100);
    
    // Create initial burst
    for (let i = 0; i < 50; i++) {
      setTimeout(createConfetti, i * 50);
    }

    return () => clearInterval(interval);
  }, []);

  return (
    <div 
      id="confetti-container" 
      className="absolute inset-0 pointer-events-none"
      data-testid="confetti-container"
    />
  );
}
