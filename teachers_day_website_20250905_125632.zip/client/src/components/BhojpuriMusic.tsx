import { useEffect, useRef, useState, useCallback } from "react";

interface BhojpuriMusicProps {
  page: "home" | "appreciation" | "celebration" | "quiz" | "advanced-quiz" | "emotional";
}

// Bhojpuri songs with different melodies for each page
const bhojpuriSongs = {
  home: {
    title: "Teachers Day Celebration Song",
    artist: "Bhojpuri Folk",
    melody: [261.63, 293.66, 329.63, 261.63, 349.23, 329.63, 293.66], // C D E C F E D
    tempo: 500
  },
  appreciation: {
    title: "Guruji Ke Sath",
    artist: "Bhojpuri Classics", 
    melody: [392.00, 349.23, 329.63, 293.66, 349.23, 392.00], // G F E D F G
    tempo: 600
  },
  celebration: {
    title: "Khushiyan Manao",
    artist: "Celebration Special",
    melody: [523.25, 493.88, 440.00, 392.00, 440.00, 493.88, 523.25], // C B A G A B C
    tempo: 400
  },
  quiz: {
    title: "Padhiye Guruji", 
    artist: "Study Time",
    melody: [220.00, 246.94, 277.18, 293.66, 277.18, 246.94, 220.00], // A B C# D C# B A
    tempo: 700
  },
  "advanced-quiz": {
    title: "Brain Challenge",
    artist: "Quiz Master",
    melody: [174.61, 196.00, 220.00, 246.94, 220.00, 196.00, 174.61], // F G A B A G F
    tempo: 300
  },
  emotional: {
    title: "Dil Se Teacher Ke Liye",
    artist: "Emotional Bhojpuri", 
    melody: [261.63, 277.18, 293.66, 311.13, 329.63, 349.23, 369.99], // C C# D D# E F F#
    tempo: 800
  }
};

export default function BhojpuriMusic({ page }: BhojpuriMusicProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [currentSong, setCurrentSong] = useState(bhojpuriSongs[page]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const currentNoteRef = useRef(0);

  useEffect(() => {
    setCurrentSong(bhojpuriSongs[page]);
    currentNoteRef.current = 0;
  }, [page]);

  const initAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return audioContextRef.current;
  }, []);

  const playNote = useCallback((frequency: number, duration: number) => {
    const audioContext = initAudioContext();
    if (!audioContext) return;

    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
    oscillator.type = 'sine';

    // Create envelope for smoother sound
    gainNode.gain.setValueAtTime(0, audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.01);
    gainNode.gain.linearRampToValueAtTime(0.05, audioContext.currentTime + duration * 0.7);
    gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + duration);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + duration);
  }, [initAudioContext]);

  const startMusic = useCallback(() => {
    if (intervalRef.current) return;

    const playMelody = () => {
      const note = currentSong.melody[currentNoteRef.current];
      playNote(note, currentSong.tempo / 1000);
      
      currentNoteRef.current = (currentNoteRef.current + 1) % currentSong.melody.length;
    };

    playMelody(); // Play first note immediately
    intervalRef.current = setInterval(playMelody, currentSong.tempo);
    setIsPlaying(true);
  }, [currentSong, playNote]);

  const stopMusic = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsPlaying(false);
  }, []);

  const toggleMusic = useCallback(async () => {
    try {
      const audioContext = initAudioContext();
      if (audioContext.state === 'suspended') {
        await audioContext.resume();
      }

      if (isPlaying) {
        stopMusic();
      } else {
        startMusic();
      }
    } catch (error) {
      console.log('Music play failed:', error);
    }
  }, [isPlaying, initAudioContext, startMusic, stopMusic]);

  useEffect(() => {
    // Auto-start music after a short delay
    const timeout = setTimeout(() => {
      if (!isPlaying) {
        toggleMusic();
      }
    }, 2000);

    return () => {
      clearTimeout(timeout);
      stopMusic();
    };
  }, [currentSong]); // Only depend on currentSong to avoid infinite loops

  useEffect(() => {
    return () => {
      stopMusic();
    };
  }, [stopMusic]);

  return (
    <>
      {/* Floating Music Controls */}
      <div 
        className={`fixed top-4 right-4 z-50 transition-all duration-300 ${showControls ? 'opacity-100' : 'opacity-70 hover:opacity-100'}`}
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
        data-testid="music-controls"
      >
        <div className="bg-gradient-to-r from-primary/90 to-secondary/90 backdrop-blur-sm rounded-2xl p-3 text-white shadow-lg">
          {showControls && (
            <div className="mb-2 text-center animate-fade-in">
              <div className="text-sm font-bold truncate max-w-48">{currentSong.title}</div>
              <div className="text-xs opacity-80 truncate">{currentSong.artist}</div>
            </div>
          )}
          
          <div className="flex items-center gap-2">
            <button
              onClick={toggleMusic}
              className="bg-white/20 hover:bg-white/30 rounded-full p-2 transition-colors duration-200"
              data-testid="music-toggle"
              title={isPlaying ? "Pause Music" : "Play Music"}
            >
              {isPlaying ? (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              ) : (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                </svg>
              )}
            </button>
            
            {showControls && (
              <div className="text-xs opacity-80">
                {isPlaying ? "🎵 Playing" : "⏸ Paused"}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Music Indicator */}
      {isPlaying && (
        <div 
          className="fixed bottom-4 right-4 z-40 bg-gradient-to-r from-green-500 to-blue-500 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse"
          data-testid="music-indicator"
        >
          🎵 Bhojpuri Music Playing
        </div>
      )}
    </>
  );
}